/**
 * This class is a wrapper over different traits of a Start-up Idea.
 *
 * @author CS1331 TAs and Nicolas Avelar
 * @version 2
 */
public class StartUpIdea implements Comparable<StartUpIdea> {

    private static final int DEFAULT_FEASIBILITY = 5;

    private String problem;
    private String targetCustomer;
    private int customerNeed;
    private int knownPeopleWithProblem;
    private int targetMarketSize;
    private String competitors;
    private int technicalFeasibility;

    /**
     * 0-arg constructor implicitly setting all instance variables to default values.
     */
    public StartUpIdea() {
    }

    /**
     * 6-arg constructor. Technical feasibility is set to a neutral default so that
     * ideas built with this constructor keep their original relative ordering.
     *
     * @param problem                description
     * @param targetCustomer         target customer
     * @param customerNeed           1-10 rating of need
     * @param knownPeopleWithProblem people you know with the problem
     * @param targetMarketSize       number of potential customer
     * @param competitors            current competitors/solutions
     */
    public StartUpIdea(String problem, String targetCustomer, int customerNeed, int knownPeopleWithProblem,
            int targetMarketSize, String competitors) {
        this(problem, targetCustomer, customerNeed, knownPeopleWithProblem, targetMarketSize, competitors,
                DEFAULT_FEASIBILITY);
    }

    /**
     * 7-arg constructor.
     *
     * @param problem                description
     * @param targetCustomer         target customer
     * @param customerNeed           1-10 rating of need
     * @param knownPeopleWithProblem people you know with the problem
     * @param targetMarketSize       number of potential customer
     * @param competitors            current competitors/solutions
     * @param technicalFeasibility   1-10 rating of how buildable a solution is today
     */
    public StartUpIdea(String problem, String targetCustomer, int customerNeed, int knownPeopleWithProblem,
            int targetMarketSize, String competitors, int technicalFeasibility) {
        this.problem = problem;
        this.targetCustomer = targetCustomer;
        this.customerNeed = customerNeed;
        this.knownPeopleWithProblem = knownPeopleWithProblem;
        this.targetMarketSize = targetMarketSize;
        this.competitors = competitors;
        this.technicalFeasibility = technicalFeasibility;
    }

    /**
     * String representation.
     *
     * @return String representation of StartUpIdea
     */
    public String toString() {
        String str = "";
        str += "Problem: " + problem + "\n";
        str += "Target Customer: " + targetCustomer + "\n";
        str += "Customer Need: " + customerNeed + "\n";
        str += "Known People With Problem: " + knownPeopleWithProblem + "\n";
        str += "Target Market Size: " + targetMarketSize + "\n";
        str += "Competitors: " + competitors + "\n";
        str += "Technical Feasibility: " + technicalFeasibility + "\n";
        return str;
    }

    /**
     * Computes the rough potential of this idea. Demand is scaled by technical
     * feasibility, so an idea nobody can build today ranks below an equally wanted
     * idea that current technology can actually deliver.
     *
     * @return the potential score of this idea
     */
    private long potentialScore() {
        long reach = (long) targetMarketSize + (long) knownPeopleWithProblem * 10000L;
        return (long) customerNeed * (long) technicalFeasibility * reach;
    }

    /**
     * A StartUpIdea is less than other StartUpIdea if it is valued higher, so that sorting them puts the best on top.
     *
     * @param other StartUpIdea to be compared
     * @return a negative integer, zero, or a positive integer following the compareTo contract.
     */
    public int compareTo(StartUpIdea other) {
        return Long.compare(other.potentialScore(), this.potentialScore());
    }

    /**
     * Getter for problem.
     *
     * @return problem
     */
    public String getProblem() {
        return problem;
    }

    /**
     * Setter for problem.
     *
     * @param problem to set
     */
    public void setProblem(String problem) {
        this.problem = problem;
    }

    /**
     * Getter for targetCustomer.
     *
     * @return targetCustomer
     */
    public String getTargetCustomer() {
        return targetCustomer;
    }

    /**
     * Setter for targetCustomer.
     *
     * @param targetCustomer to set
     */
    public void setTargetCustomer(String targetCustomer) {
        this.targetCustomer = targetCustomer;
    }

    /**
     * Getter for customerNeed.
     *
     * @return customerNeed
     */
    public int getCustomerNeed() {
        return customerNeed;
    }

    /**
     * Setter for customerNeed.
     *
     * @param customerNeed to set
     */
    public void setCustomerNeed(int customerNeed) {
        this.customerNeed = customerNeed;
    }

    /**
     * Getter for knownPeopleWithProblem.
     *
     * @return knownPeopleWithProblem
     */
    public int getKnownPeopleWithProblem() {
        return knownPeopleWithProblem;
    }

    /**
     * Setter for knownPeopleWithProblem.
     *
     * @param knownPeopleWithProblem to set
     */
    public void setKnownPeopleWithProblem(int knownPeopleWithProblem) {
        this.knownPeopleWithProblem = knownPeopleWithProblem;
    }

    /**
     * Getter for targetMarketSize.
     *
     * @return targetMarketSize
     */
    public int getTargetMarketSize() {
        return targetMarketSize;
    }

    /**
     * Setter for targetMarketSize.
     *
     * @param targetMarketSize to set
     */
    public void setTargetMarketSize(int targetMarketSize) {
        this.targetMarketSize = targetMarketSize;
    }

    /**
     * Getter for competitors.
     *
     * @return competitors
     */
    public String getCompetitors() {
        return competitors;
    }

    /**
     * Setter for competitors.
     *
     * @param competitors to set
     */
    public void setCompetitors(String competitors) {
        this.competitors = competitors;
    }

    /**
     * Getter for technicalFeasibility.
     *
     * @return technicalFeasibility
     */
    public int getTechnicalFeasibility() {
        return technicalFeasibility;
    }

    /**
     * Setter for technicalFeasibility.
     *
     * @param technicalFeasibility to set
     */
    public void setTechnicalFeasibility(int technicalFeasibility) {
        this.technicalFeasibility = technicalFeasibility;
    }

}
