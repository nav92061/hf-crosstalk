import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * JavaFX application for recording and ranking startup ideas.
 *
 * <p>
 * Collaboration Statement:
 * I worked on the homework assignment alone, using only course materials.
 *
 * @author Nicolas Avelar
 * @version 4.0
 */
public class StarterUpper extends Application {

    private static final String[] FIELD_LABELS = {
        "Problem: ",
        "Target Customer: ",
        "Customer Need: ",
        "Known People With Problem: ",
        "Target Market Size: ",
        "Competitors: ",
        "Technical Feasibility: "
    };

    private List<StartUpIdea> ideaList = new ArrayList<>();
    private ObservableList<String> displayedProblems =
            FXCollections.observableArrayList();

    private TextField problemField;
    private TextField targetCustomerField;
    private TextField needField;
    private TextField knownPeopleField;
    private TextField targetMarketField;
    private TextField competitorsField;
    private TextField feasibilityField;
    private ListView<String> problemList;
    private int selectedIdeaIndex = -1;

    /**
     * Creates and displays the JavaFX application.
     *
     * @param primaryStage the primary application stage
     */
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Problem Ideation Form");

        Label initialsLabel = new Label("Initials: N.A.");
        initialsLabel.setStyle(
                "-fx-font-size: 16px;"
                + "-fx-font-weight: bold;"
                + "-fx-text-fill: #003057;"
        );

        Button gtidButton = new Button("GTID: 904189050");
        gtidButton.setStyle(
                "-fx-background-color: #B3A369;"
                + "-fx-text-fill: white;"
                + "-fx-font-weight: bold;"
        );

        HBox headerBox = new HBox(20, initialsLabel, gtidButton);
        headerBox.setAlignment(Pos.CENTER);

        Label titleLabel = new Label("Startup Idea Evaluator");
        titleLabel.setStyle(
                "-fx-font-size: 22px;"
                + "-fx-font-weight: bold;"
                + "-fx-text-fill: #003057;"
        );

        GridPane grid = createForm();

        Button addButton = new Button("Add Idea");
        Button sortButton = new Button("Sort Ideas");
        Button saveButton = new Button("Save Ideas");
        Button resetButton = new Button("Reset Form");
        Button updateButton = new Button("Update Selected");

        styleButton(addButton, "#2E7D32");
        styleButton(sortButton, "#1565C0");
        styleButton(saveButton, "#B3A369");
        styleButton(resetButton, "#C62828");
        styleButton(updateButton, "#6A1B9A");

        HBox mainButtonBox = new HBox(
                10, addButton, sortButton, saveButton, resetButton
        );
        mainButtonBox.setAlignment(Pos.CENTER);

        HBox editButtonBox = new HBox(10, updateButton);
        editButtonBox.setAlignment(Pos.CENTER);

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                handleAddIdea();
            }
        });

        sortButton.setOnAction(event -> handleSort());
        saveButton.setOnAction(event -> handleSave());
        resetButton.setOnAction(event -> handleReset());
        updateButton.setOnAction(event -> handleUpdateIdea());

        Label submittedLabel = new Label("Submitted Startup Problems");
        submittedLabel.setStyle(
                "-fx-font-size: 17px;"
                + "-fx-font-weight: bold;"
                + "-fx-text-fill: #003057;"
        );

        problemList = new ListView<>(displayedProblems);
        problemList.setPrefWidth(650);
        problemList.setPrefHeight(150);
        problemList.setPlaceholder(
                new Label("No startup ideas have been added yet.")
        );
        problemList.getSelectionModel().selectedIndexProperty()
                .addListener((observable, oldValue, newValue) -> {
                    int index = newValue.intValue();
                    if (index >= 0 && index < ideaList.size()) {
                        loadIdeaIntoFields(index);
                    }
                });

        VBox root = new VBox(
                12,
                headerBox,
                titleLabel,
                grid,
                mainButtonBox,
                submittedLabel,
                problemList,
                editButtonBox
        );
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #F5F7FA;");

        loadIdeasFromFile();

        Scene scene = new Scene(root, 780, 720);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Creates the startup idea form.
     *
     * @return the completed form
     */
    private GridPane createForm() {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(15));
        grid.setAlignment(Pos.CENTER);
        grid.setStyle(
                "-fx-background-color: white;"
                + "-fx-border-color: #B3A369;"
                + "-fx-border-width: 2px;"
                + "-fx-border-radius: 8px;"
                + "-fx-background-radius: 8px;"
        );

        problemField = new TextField();
        targetCustomerField = new TextField();
        needField = new TextField();
        knownPeopleField = new TextField();
        targetMarketField = new TextField();
        competitorsField = new TextField();
        feasibilityField = new TextField();

        problemField.setPromptText("Describe the problem");
        targetCustomerField.setPromptText("Describe the customer");
        needField.setPromptText("Integer from 1 to 10");
        knownPeopleField.setPromptText("Nonnegative integer");
        targetMarketField.setPromptText("Nonnegative integer");
        competitorsField.setPromptText("List specific competitors");
        feasibilityField.setPromptText("Integer from 1 to 10");

        problemField.setPrefWidth(320);
        targetCustomerField.setPrefWidth(320);
        competitorsField.setPrefWidth(320);

        grid.add(new Label("What is the problem?"), 0, 0);
        grid.add(problemField, 1, 0);
        grid.add(new Label("Who is the target customer?"), 0, 1);
        grid.add(targetCustomerField, 1, 1);
        grid.add(new Label(
                "How badly does the customer NEED this fixed (1-10)?"
        ), 0, 2);
        grid.add(needField, 1, 2);
        grid.add(new Label(
                "How many people do you know who might experience this problem?"
        ), 0, 3);
        grid.add(knownPeopleField, 1, 3);
        grid.add(new Label("How big is the target market?"), 0, 4);
        grid.add(targetMarketField, 1, 4);
        grid.add(new Label(
                "Who are the competitors/existing solutions?"
        ), 0, 5);
        grid.add(competitorsField, 1, 5);
        grid.add(new Label(
                "How buildable is a solution with current technology (1-10)?"
        ), 0, 6);
        grid.add(feasibilityField, 1, 6);

        return grid;
    }

    /**
     * Applies a background color to a button.
     *
     * @param button the button to style
     * @param color the hexadecimal background color
     */
    private void styleButton(Button button, String color) {
        button.setStyle(
                "-fx-background-color: " + color + ";"
                + "-fx-text-fill: white;"
                + "-fx-font-weight: bold;"
                + "-fx-padding: 8px 14px;"
        );
    }

    /**
     * Validates and adds the current startup idea.
     */
    private void handleAddIdea() {
        StartUpIdea idea = createIdeaFromFields();
        if (idea == null) {
            return;
        }

        ideaList.add(idea);
        refreshDisplayedProblems();
        clearFields();
    }

    /**
     * Updates the selected startup idea with the current field values.
     */
    private void handleUpdateIdea() {
        if (selectedIdeaIndex < 0 || selectedIdeaIndex >= ideaList.size()) {
            showAlert(
                    Alert.AlertType.WARNING,
                    "No Idea Selected",
                    "Select an idea from the list before updating it."
            );
            return;
        }

        int updateIndex = selectedIdeaIndex;
        StartUpIdea updatedIdea = createIdeaFromFields();
        if (updatedIdea == null) {
            return;
        }

        ideaList.set(updateIndex, updatedIdea);
        refreshDisplayedProblems();
        clearFields();
    }

    /**
     * Creates an idea from the form after validating every field.
     *
     * @return a valid idea, or null when at least one field is invalid
     */
    private StartUpIdea createIdeaFromFields() {
        String problem = problemField.getText().trim();
        String targetCustomer = targetCustomerField.getText().trim();
        String needString = needField.getText().trim();
        String knownPeopleString = knownPeopleField.getText().trim();
        String targetMarketString = targetMarketField.getText().trim();
        String competitors = competitorsField.getText().trim();
        String feasibilityString = feasibilityField.getText().trim();

        if (problem.isEmpty()
                || targetCustomer.isEmpty()
                || needString.isEmpty()
                || knownPeopleString.isEmpty()
                || targetMarketString.isEmpty()
                || competitors.isEmpty()
                || feasibilityString.isEmpty()) {
            showInvalidInputAlert();
            return null;
        }

        try {
            int customerNeed = Integer.parseInt(needString);
            int knownPeople = Integer.parseInt(knownPeopleString);
            int targetMarket = Integer.parseInt(targetMarketString);
            int feasibility = Integer.parseInt(feasibilityString);

            if (customerNeed < 1 || customerNeed > 10
                    || feasibility < 1 || feasibility > 10
                    || knownPeople < 0 || targetMarket < 0) {
                showInvalidInputAlert();
                return null;
            }

            return new StartUpIdea(
                    problem,
                    targetCustomer,
                    customerNeed,
                    knownPeople,
                    targetMarket,
                    competitors,
                    feasibility
            );
        } catch (NumberFormatException exception) {
            showInvalidInputAlert();
            return null;
        }
    }

    /**
     * Sorts the startup ideas by their natural ordering.
     */
    private void handleSort() {
        Collections.sort(ideaList);
        refreshDisplayedProblems();
        clearFields();
    }

    /**
     * Saves all startup ideas to ideas.txt.
     */
    private void handleSave() {
        File saveFile = new File("ideas.txt");
        boolean successful = FileUtil.saveIdeasToFile(ideaList, saveFile);

        if (!successful) {
            showAlert(
                    Alert.AlertType.ERROR,
                    "Save Failed",
                    "The startup ideas could not be saved."
            );
        }
    }

    /**
     * Confirms and performs a complete application reset.
     */
    private void handleReset() {
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirm Reset");
        confirmation.setHeaderText("Reset Application");
        confirmation.setContentText(
                "Are you sure you want to clear all ideas "
                + "and delete ideas.txt?"
        );
        Optional<ButtonType> result = confirmation.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            File saveFile = new File("ideas.txt");
            if (saveFile.exists()) {
                saveFile.delete();
            }

            ideaList.clear();
            displayedProblems.clear();
            clearFields();
        }
    }

    /**
     * Loads saved startup ideas when ideas.txt exists. Any unreadable entry is
     * skipped silently so that startup is never blocked.
     */
    private void loadIdeasFromFile() {
        File saveFile = new File("ideas.txt");
        if (!saveFile.exists()) {
            return;
        }

        List<String> lines = readAllLines(saveFile);
        int index = 0;
        while (index < lines.size()) {
            StartUpIdea idea = parseIdea(lines, index);
            if (idea == null) {
                index++;
            } else {
                ideaList.add(idea);
                index += FIELD_LABELS.length;
            }
        }
        refreshDisplayedProblems();
    }

    /**
     * Reads every line of a file.
     *
     * @param file the file to read
     * @return the lines of the file, or an empty list if it cannot be opened
     */
    private List<String> readAllLines(File file) {
        List<String> lines = new ArrayList<>();
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                lines.add(scanner.nextLine());
            }
        } catch (FileNotFoundException exception) {
            return lines;
        }
        return lines;
    }

    /**
     * Parses one saved idea beginning at the given line.
     *
     * @param lines every line of the saved file
     * @param start index of the expected first labeled line
     * @return the parsed idea, or null if the lines are not a valid idea
     */
    private StartUpIdea parseIdea(List<String> lines, int start) {
        String[] values = new String[FIELD_LABELS.length];
        for (int offset = 0; offset < FIELD_LABELS.length; offset++) {
            int lineIndex = start + offset;
            if (lineIndex >= lines.size()) {
                return null;
            }
            String line = lines.get(lineIndex);
            if (!line.startsWith(FIELD_LABELS[offset])) {
                return null;
            }
            values[offset] = line.substring(FIELD_LABELS[offset].length());
        }

        try {
            return new StartUpIdea(
                    values[0],
                    values[1],
                    Integer.parseInt(values[2].trim()),
                    Integer.parseInt(values[3].trim()),
                    Integer.parseInt(values[4].trim()),
                    values[5],
                    Integer.parseInt(values[6].trim())
            );
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    /**
     * Loads the selected idea into the editing controls.
     *
     * @param index index of the selected idea
     */
    private void loadIdeaIntoFields(int index) {
        selectedIdeaIndex = index;
        StartUpIdea idea = ideaList.get(index);
        problemField.setText(idea.getProblem());
        targetCustomerField.setText(idea.getTargetCustomer());
        needField.setText(Integer.toString(idea.getCustomerNeed()));
        knownPeopleField.setText(
                Integer.toString(idea.getKnownPeopleWithProblem())
        );
        targetMarketField.setText(
                Integer.toString(idea.getTargetMarketSize())
        );
        competitorsField.setText(idea.getCompetitors());
        feasibilityField.setText(
                Integer.toString(idea.getTechnicalFeasibility())
        );
    }

    /**
     * Refreshes the problems displayed in the ListView.
     */
    private void refreshDisplayedProblems() {
        displayedProblems.clear();
        for (int index = 0; index < ideaList.size(); index++) {
            displayedProblems.add(
                    (index + 1) + ". " + ideaList.get(index).getProblem()
            );
        }
        selectedIdeaIndex = -1;
        if (problemList != null) {
            problemList.getSelectionModel().clearSelection();
        }
    }

    /**
     * Clears every form field.
     */
    private void clearFields() {
        problemField.clear();
        targetCustomerField.clear();
        needField.clear();
        knownPeopleField.clear();
        targetMarketField.clear();
        competitorsField.clear();
        feasibilityField.clear();
        selectedIdeaIndex = -1;
        if (problemList != null) {
            problemList.getSelectionModel().clearSelection();
        }
    }

    /**
     * Displays the standard invalid-input alert.
     */
    private void showInvalidInputAlert() {
        showAlert(
                Alert.AlertType.ERROR,
                "Invalid Input",
                "At least one value is invalid. Fill in every field, "
                + "enter a customer need and a feasibility rating from "
                + "1 to 10, and enter nonnegative integers for the other "
                + "numeric fields."
        );
    }

    /**
     * Creates and displays an alert.
     *
     * @param alertType the alert type
     * @param title the alert title
     * @param message the alert message
     */
    private void showAlert(
            Alert.AlertType alertType,
            String title,
            String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
